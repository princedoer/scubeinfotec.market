<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png" />
    <link rel="icon" type="image/png" href="assets/img/favicon.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Admin Panel | Home Page  | SCube Infotec</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
	<?php include("headercss.php"); ?>
</head>

<body>
    <div class="wrapper">
	<?php include("mainmenu.php");?>
        <div class="main-panel">
	<?php include("header.php");?>
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-8 col-md-12 col-sm-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                     <h4 class="title">Trading Session</h4>
                                </div>
                                <div class="card-content">
									<p class="category"><?php
if(date('D') == 'MON' || date('D') == 'Sun') { 
  echo '<div class="alert alert-danger alert-with-icon" data-notify="container">
            <i data-notify="icon" class="material-icons">add_alert</i>
			<span data-notify="message"><h3> <blink>  Today Market is Holiday!... </blink></h3> </span>
        </div>';
} else {
	
date_default_timezone_set('Asia/Calcutta');
$current_time= date("h:i:sa");
$market_open='10:43:00 am';
$market_close='11:30:00 pm';
if($current_time >$market_open) { 
echo "The time is " . date("h:i:sa");
  echo "Today is not Saturday or Sunday.";
}
}
?></p>
                                    <h3 class="title">
                                        <small></small>
                                    </h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 col-sm-12">
							<div class="card card-stats">
                                <div class="card-header" data-background-color="blue">
                                    <i class="fa fa-twitter"></i>
                                </div>
                                <div class="card-content">
                                    <p class="category">Followers</p>
                                    <h3 class="title"><a href="https://twitter.com/TwitterDev?ref_src=twsrc%5Etfw"  data-show-count="false">  <i class="fa fa-twitter"></i></a><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script></h3>
                                </div>
                            </div>
                            
                    </div>
                            
                    </div>
                    <div class="row">
                        <div class="col-lg-8 col-md-12 col-sm-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <h4 class="title">Economic Calendar</h4>
                                </div>
                                <div class="card-content">
									<iframe src="https://sslecal2.forexprostools.com?ecoDayBackground=%23ffffff&ecoDayFontColor=%23000000&columns=exc_flags,exc_currency,exc_importance,exc_actual,exc_forecast,exc_previous&category=_employment,_economicActivity,_inflation,_credit,_centralBanks,_confidenceIndex,_balance,_Bonds&importance=1,2,3&features=datepicker,timezone,timeselector,filters&countries=14&calType=day&timeZone=23&lang=56" width="100%" height="300" frameborder="0" allowtransparency="true" marginwidth="0" marginheight="0"></iframe>
									<div class="poweredBy" style="font-family: Arial, Helvetica, sans-serif;">
										<span style="font-size: 11px;color: #333333;text-decoration: none;">
											Real Time Economic Calendar provided by <a href="https://in.Investing.com/" rel="nofollow" target="_blank" style="font-size: 11px;color: #06529D; font-weight: bold;" class="underline_link">Investing.com India</a>.
										</span>
									</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 col-sm-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header card-chart">
                                    <div class="ct-chart"><iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fscubeinfotec&tabs=timeline&width=300&height=600&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=220266458000798" width="100%" height="auto" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe></div>
                                </div>
                                <div class="card-content">
								</div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 col-sm-12">
							<div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <h4 class="title"> Shortcuts</h4>
                                </div>
                                <div class="card-content">
									<div class="row">
										<div class="col-md-6">
											<div class="alert alert-danger">
												<span><a href="chart.php">Live Chart</a></span>
											</div>
										</div>
										<div class="col-md-6">
											<div class="alert alert-success">
												<span>
													<a href="scubelevel.php">Pivot Level</a>
												</span>
											</div>
										</div>
									</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
						<div class="col-lg-8 col-md-12 col-sm-12">
                            <div class="card">
                                <div class="card-header" data-background-color="orange">
                                    <h4 class="title">MCX News</h4>
                                </div>
                                <div class="card-content">
									<script type="text/javascript">var _mcq=["10","4d4345"];</script><span id='_mc_mg10'></span><script language="JavaScript" src="http://stat1.moneycontrol.com/mcjs/common/mc_widget_v2.js"></script></script><noscript><a href="http://www.moneycontrol.com/india/stockpricequote/miscellaneous/multicommodityexchangeindia/MCE">Multi Commodity Exchange of India</a></noscript>
                                </div>
                            </div>
                        </div>
					</div>
                </div>
            </div>	
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/material.min.js" type="text/javascript"></script>
<!--  PerfectScrollbar Library -->
<script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/js/bootstrap-notify.js"></script>
<!-- Material Dashboard javascript methods -->
<script src="assets/js/material-dashboard.js?v=1.2.0"></script><script>
</html>