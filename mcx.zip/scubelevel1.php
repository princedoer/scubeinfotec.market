<?php
//include ('../session.php');
//include ('../connection.php');
//include ('scubelogincheck.php');
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="assets/img/favicons.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Level| SCube Infotec</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
	<?php include("headercss.php"); ?>
    <link rel="stylesheet" href="https://rawgit.com/MEYVN-digital/mdl-selectfield/master/mdl-selectfield.min.css">
</head>

<body>
    <div class="wrapper">
	<?php include("mainmenu.php"); ?>
        <div class="main-panel">
			<div class="content" style="margin-top: 10px;padding-top: 10px;">
                <div class="container-fluid">
		<form method="GET" id="levels">
                    <div class="row">
                        <div class="col-md-3">
							<div>
        <select class="mdl-selectfield__select" id="scripname" name="scripname">
							<?php
								$sql3=mysql_query("SELECT id, symbol FROM scube_ohlc group by symbol");
								if($_GET['scripname']=='')
								{
								?>
								<option value="CRUDEOIL" Selected>CRUDEOIL</option>
								 
                                <?php
								}
								else
								{
								?>
								<option value="<?=$_GET['scripname']?>" Selected><?=$_GET['scripname']?></option>
                                <?php
								}
								?>
            <option value="" >Select</option>
								<?php
								while($row3=mysql_fetch_array($sql3))
                                    {
                            ?>
                                        <option value="<?=$row3['symbol']?>"><?=$row3['symbol']?></option>
                            <?php
                                    }
                            ?>
        </select>
        <label class="mdl-selectfield__label" for="scripname">Scrip Name</label>
      </div>
						</div>             
                        <div class="col-md-3">
						
							<div>
        <select class="mdl-selectfield__select" id="expirydatename" name="expirydatename">
								<?php
								$sql3=mysql_query("SELECT id, symbol,  FROM scube_ohlc group by symbol");
								if(($_GET['scripname']!='')&&($_GET['expirydatename']!=''))
								{
								?>
								 <option value="<?=$_GET['expirydatename']?>" Selected><?=$_GET['expirydatename']?></option>
                                <?php
								}
								if(($_GET['scripname']=='')&&($_GET['expirydatename']==''))
								{
								?>
								 <option value="17-11-17" Selected>17-11-17</option>
                                <?php
								}
								?>
								
                      <option value="" >Select</option>
								<?php
								$sql4=mysql_query("SELECT id, symbol, expirydate  FROM scube_ohlc where symbol='".$_GET['scripname']."'");
								while($row4=mysql_fetch_array($sql4))
                                    {
                            ?>
                                        <option value="<?=$row4['expirydate']?>"><?=$row4['expirydate']?></option>
                            <?php
                                    }
                            ?>
        </select>
        <label class="mdl-selectfield__label" for="expirydatename">Expiry Date</label>
      </div>
						
						</div>
                        <div class="col-md-2"><button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored mdl-js-ripple-effect" id="target">Show</button>
						
						</div>
						</div>
						</form>
                    <div class="row">
                        <div class="col-md-10">
						
						<div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <div class="nav-tabs-navigation">
                                        <div class="nav-tabs-wrapper">
                                            <ul class="nav nav-tabs" data-tabs="tabs">
											<?php 
		$scrpname=(isset($_GET['scripname']))?$_GET['scripname']:'CRUDEOIL';
		$expirydate=(isset($_GET['expirydatename']))?$_GET['expirydatename']:'18-10-17';
		
				// I just made an array with some data, since I don't have your data source
					$sqlCat =   array(
									array('tab_title'=>'ScubeLevel','tab_head'=>'Scube Level'),
									array('tab_title'=>'StandardLevel','tab_head'=>'Standard Level'),
									array('tab_title'=>'FibonacciLevel','tab_head'=>'Fibonacci Level'),
									array('tab_title'=>'WoodieLevel','tab_head'=>'Woodie Level'),
									array('tab_title'=>'DemarkLevel','tab_head'=>'Demark Level')
									);
					//set the current tab to be the first one in the list.... or whatever one you specify
					$current_tab = $sqlCat[0]['tab_title'];
								
    foreach ($sqlCat as $row):
        //set the class to "active" for the active tab.
        $tab_class = ($row['tab_title']==$current_tab) ? 'active' : '' ;
        echo '<li class="'.$tab_class.'">';
        echo '<a href="#' . urlencode($row['tab_title']) .  '" data-toggle="tab"  class="mdl-layout__tab '.$tab_class.'"><i class="material-icons">code</i> ' .           
        $row['tab_head'] .  '<div class="ripple-container"></div> </a>';
        echo '</li>';
    endforeach;
    ?>
                                               
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-content">
                                    <div class="tab-content">
	  <?php foreach ($sqlCat as $row2): 
        $tab = $row2['tab_title'];
        //set the class to "active" for the active content.
        $content_class = ($tab==$current_tab) ? 'active' : '' ;
        ?>
                                        <div class="tab-pane <?php echo $content_class;?>" id="<?php echo $tab;?>" >
													
													<?php     
//Variable Declaration		
				$pivt='';
				$sup1='';
				$sup2='';
				$sup3='';
				$res1='';
				$res2='';
				$res3=''; 
				$curtab=''; 
			if($tab=="ScubeLevel")
			{
				$pivt='scpv';
				$sup1='scs1';
				$sup2='scs2';
				$sup3='scs3';
				$res1='scr1';
				$res2='scr2';
				$res3='scr3';
			}
			if($tab=="StandardLevel")
			{
				$pivt='spv';
				$sup1='ss1';
				$sup2='ss2';
				$sup3='ss3';
				$res1='sr1';
				$res2='sr2';
				$res3='sr3';
			}
			if($tab=="FibonacciLevel")
			{
				$pivt='fpv';
				$sup1='fs1';
				$sup2='fs2';
				$sup3='fs3';
				$res1='fr1';
				$res2='fr2';
				$res3='fr3';
			}
			if($tab=="WoodieLevel")
			{
				$pivt='wpv';
				$sup1='ws1';
				$sup2='ws2';
				$sup3='ws3';
				$res1='wr1';
				$res2='wr2';
				$res3='wr3';
			}
			if($tab=="DemarkLevel")
			{
				$pivt='dpv';
				$sup1='ds1';
				$res1='dr1';
$sqlquery1="SELECT id, createdon, editedon, date, symbol, expirydate, open, high, low, close, previousclose, volume, volume_units, value, openinterest, tradingunit, unit, pertick, pricepertick, commoditytype, commoditycategory, pricequote, marginpercent, totalmargin, spanmargin, $pivt, $sup1,  $res1 from scube_ohlc where tdelete='0' and symbol='$scrpname' and expirydate='$expirydate'";
			}
			if($tab!="DemarkLevel")
			{
				
$sqlquery1="SELECT id, createdon, editedon, date, symbol, expirydate, open, high, low, close, previousclose, volume, volume_units, value, openinterest, tradingunit, unit, pertick, pricepertick, commoditytype, commoditycategory, pricequote, marginpercent, totalmargin, spanmargin, $pivt, $sup1, $sup2, $sup3, $res1, $res2, $res3 from scube_ohlc where tdelete='0' and symbol='$scrpname' and expirydate='$expirydate'";
			}
$sqlquery=mysql_query($sqlquery1);
$infosql=mysql_fetch_array($sqlquery);
				?>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header" data-background-color="blue">
                                    <h4 class="title"><?=$infosql['symbol']?></h4>
                                    <p class="category">Material Type:<?=strtoupper($infosql['commoditytype'])?></p>
                                </div>
                                <div class="card-content table-responsive">
                                    <table class="table">
                                        <tbody>
					<?php
		  
			if($tab=="DemarkLevel")
			{
				?>	
                                            <tr>
                                                <td align="center"><h4 class="title">R1</h4></td>
                                                <td align="center"><h4 class="title"><?=$infosql[$res1]?></h4></td>
                                            </tr>
                                            <tr>
                                                <td align="center"><h4 class="title">Pivot</h4></td>
                                                <td align="center"><h4 class="title"><?=$infosql[$pivt]?></h4></td>
                                            </tr>
                                            <tr>
                                                <td align="center"><h4 class="title">S1</h4></td>
                                                <td align="center"><h4 class="title"><?=$infosql[$sup1]?></h4></td>
                                            </tr>
											
		<?php
			}
		if($tab!="DemarkLevel")
			{
			?>
                                            <tr>
                                                <td align="center"><h4 class="title">R3</h4></td>
                                                <td align="center"><h4 class="title"><?=$infosql[$res3]?></h4></td>
                                            </tr>
                                            <tr>
                                                <td align="center"><h4 class="title">R2</h4></td>
                                                <td align="center"><h4 class="title"><?=$infosql[$res2]?></h4></td>
                                            </tr>
                                            <tr>
                                                <td align="center"><h4 class="title">R1</h4></td>
                                                <td align="center"><h4 class="title"><?=$infosql[$res1]?></h4></td>
                                            </tr>
                                            <tr>
                                                <td align="center"><h4 class="title"><strong>Pivot</strong></h4></td>
                                                <td align="center"><h4 class="title"><strong><?=$infosql[$pivt]?></strong></h4></td>
                                            </tr>
                                            <tr>
                                                <td align="center"><h4 class="title">S1</h4></td>
                                                <td align="center"><h4 class="title"><?=$infosql[$sup1]?></h4></td>
                                            </tr>
                                            <tr>
                                                <td align="center"align="center"><h4 class="title">S2</td>
                                                <td align="center"align="center"><h4 class="title"><?=$infosql[$sup2]?></h4></td>
                                            </tr>
                                            <tr>
                                                <td align="center"><h4 class="title">S3</h4></td>
                                                <td align="center"><h4 class="title"><?=$infosql[$sup3]?></h4></td>
                                            </tr>
											<?php
			}
			?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
						
                        <div class="col-md-6">
                            <div class="card card-stats">
                                <div class="card-content">
                                    <h3 class="title pull-left">Lot Size: <?=$infosql['tradingunit'].'&nbsp;'.$infosql['unit']?></h3>
                                </div>
                            </div>
                            <div class="card card-stats">
                                <div class="card-content">
                                    <h3 class="title pull-left">Price Per Tick: &#8377;<?='&nbsp;'.$infosql['pricepertick']?></h3>
                                </div>
                            </div>
							</div>
                                        </div>
                                        
										 <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		<?php include("footer.php"); ?>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/material.min.js" type="text/javascript"></script>
<!--  Charts Plugin -->
<script src="assets/js/chartist.min.js"></script>
<!--  Dynamic Elements plugin -->
<script src="assets/js/arrive.min.js"></script>
<!--  PerfectScrollbar Library -->
<script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/js/bootstrap-notify.js"></script>
<!-- Material Dashboard javascript methods -->
<script src="assets/js/material-dashboard.js?v=1.2.0"></script>
<!-- Material Dashboard DEMO methods, don't include it in your project!
<script src="assets/js/demo.js"></script> -->

<script type="text/javascript">
$("#scripname").change(function () {		
var scripname = $("#scripname").find("option:selected").val();
var expirydate = $("#expirydate").find("option:selected").val();
$('#scripid').val( scripname );
$.ajax
({
type: "POST",
url: "scubexpiryajax.php",
data:{symbol: scripname,},
cache: false,
success: function(html)
{	
$("#expirydatename").html(html);

}
});
    });
$( "#target" ).click(function() {
	var scripname = $("#scripname").find("option:selected").val();
	var expirydatename = $("#expirydatename").find("option:selected").val();
	var dataString = 'scripname='+ scripname +'&'+'expirydatename='+ expirydatename;
	
	 window.location.href = "scubelevel.php?" + dataString; 
});

</script>

</html>