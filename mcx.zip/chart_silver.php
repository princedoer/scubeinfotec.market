<?php
include ('../session.php');
include ('../connection.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="assets/img/favicons.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Silver Live Chart | SCube Infotec</title>
	<meta name="description" content="Get detailed information about Silver Chart">
	<meta name="keywords" content="silver price, silver price India, silver price in India, silver price today, India silver price, live silver price, silver India, India silver, silver rate today, silver rate India, mcx silver, silver prices"/>
	<meta http-equiv="pragma" content="no-cache">
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />	
	<meta name="twitter:card" content="Silver Live Chart">
	<meta name="twitter:site" content="@Scubeinfotec">
	<meta name="twitter:creator" content="@Scubeinfotec">
	<meta name="twitter:title" content="Silver Live Chart">
	<meta name="twitter:description" content="Silver Live Chart">
	<meta name="twitter:image" content="img/comm_charts/Silver.png">
	<meta property="og:title" content="Silver Live Chart" />
	<meta property="og:description" content="Silver Live Chart" />
	<meta property="og:url" content="http://scubeinfotec.co.in" />
	<meta property="og:image" content="http://mcx.scubeinfotec.co.in/img/comm_charts/Silver.png" />
	<?php include("headercss.php"); ?>
	<style>
		@media only screen and (max-width: 768px) {
		.contentsm{
			padding-left: 0px;
			padding-right: 0px;
			padding-top: 50px;
		}
		.addiv{
			display: none;
		}
		} 
#share-buttons img {
width: 35px;
padding: 5px;
border: 0;
box-shadow: 0;
display: inline;
}
.blink {
    animation-duration: 1s;
    animation-name: blink;
    animation-iteration-count: infinite;
    animation-timing-function: steps(2, start);
}
@keyframes blink{
    80% {
        visibility: hidden;
    }
}
	</style>
</head>
<body>
    <div class="wrapper">
		<?php include("mainmenu.php"); ?>
			<div class="main-panel">
		<?php include("headersm.php"); ?>
					<div class="content" style="padding-top: 15px;margin-top:0px;">
						<div class="container-fluid">
							<div class="row">
								<div class="col-lg-10 col-md-12 col-sm-12 contentsm">
									<div class="card">
										<div class="card-header" data-background-color="purple">
											<h4 class="title blink">Silver Live Intraday Chart</h4>
										</div>
										<div class="card-content">
											<div class="row">
												<div class="col-md-12">
													<div id="div">
														<table class="table">
															<tbody>
																<tr>
																	<td colspan="4" id="streamTitle">
																		<img id="imageid_Silverintra" src="img/comm_charts/SilverIntra.png" class="auto_img" alt="Silver"> 
																	</td>
																</tr>
																<tr>
																<td colspan="4"></td>
																</tr>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--Advertisement-->
								<div class="col-lg-2 col-md-12 col-sm-12 contentsm addiv">
									<h6>Advertisement</h6>	 
									<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
										<!-- ad3 -->
										<ins class="adsbygoogle"
											 style="display:inline-block;width:200px;height:600px"
											 data-ad-client="ca-pub-7550523212472920"
											 data-ad-slot="5417275659"></ins>
									<script>
										(adsbygoogle = window.adsbygoogle || []).push({});
									</script>
										
								</div>
								<!--/.Advertisement-->
							</div>
						</div>
						<div class="container-fluid">
							<div class="row">
								<div class="col-lg-10 col-md-12 col-sm-12 contentsm">
									<div class="card">
										<div class="card-header" data-background-color="purple">
											<h4 class="title blink">Silver Live Short-term Positional Chart</h4>
											
										</div>
										<div class="card-content">
											<div class="row">
												<div class="col-md-12">
													<div id="div">
														<table class="table">
															<tbody>
																<tr id="screen">
																	<td colspan="4">
																	 <img id="imageid_Silver" src="img/comm_charts/SilverIntra.png" alt="Silver">  
																	</td>
																</tr>
																<tr>
																<td colspan="4"></td>
																</tr>
															</tbody>	
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--Advertisement-->
								<div class="col-lg-2 col-md-12 col-sm-12 contentsm addiv">
									<h6>Advertisement</h6>
									<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
									<!-- ad3 -->
									<ins class="adsbygoogle"
										 style="display:inline-block;width:200px;height:600px"
										 data-ad-client="ca-pub-7550523212472920"
										 data-ad-slot="5417275659"></ins>
									<script>
									(adsbygoogle = window.adsbygoogle || []).push({});
									</script>
								</div>
								<!--/.Advertisement-->
							</div>
						</div>
					<?php include("footeraboutchart.php") ?>
					</div>
				<?php include("footer.php"); ?>
			</div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/material.min.js" type="text/javascript"></script>
<!--  Charts Plugin -->
<!--  PerfectScrollbar Library -->
<script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
<!-- Material Dashboard javascript methods -->
<script src="assets/js/material-dashboard.js?v=1.2.0"></script>
<script type="text/javascript">
  var d = new Date().getTime();
function refresh_div() {
    var d = new Date().getTime();
            $("#imageid_Silver").attr("src", "img/comm_charts/Silver.png?"+d);
            $("#imageid_Silverintra").attr("src", "img/comm_charts/SilverIntra.png?"+d);
}
t = setInterval(refresh_div,5000);  
 window.oncontextmenu = function () {
            return false;
        }
        $(document).keydown(function (event) {
            if (event.keyCode == 123) {
                return false;
            }
            else if ((event.ctrlKey && event.shiftKey && event.keyCode == 73) || (event.ctrlKey && event.shiftKey && event.keyCode == 74)) {
                return false;
            }
        });  
		    $(document).keydown(function(event) { 
        var pressedKey = String.fromCharCode(event.keyCode).toLowerCase();
        
        if (event.ctrlKey && (pressedKey == "c" || pressedKey == "u")) {
            alert('Sorry, This Functionality Has Been Disabled!'); 
            //disable key press porcessing
            return false; 
        }
    });
		 
</script>
</html>