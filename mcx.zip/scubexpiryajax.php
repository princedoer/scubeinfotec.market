<?php 
include ('../connection.php');
if($_POST['symbol'])
{
$symbol=$_POST['symbol'];
$expdate=date('d-M-y');
$sql=mysql_query("SELECT id, expirydate FROM scube_ohlc where symbol='$symbol'");
while($row=mysql_fetch_array($sql))
{
$expirydate=$row['expirydate'];
if($symbol!='')
{
	echo '<option value="'.$expirydate.'" selected>'.$expirydate.'</option>';	
}
else
{
	echo '<option value="'.$expirydate.'">'.$expirydate.'</option>';
}
} 
}
?>