<?php
 include ('../session.php');
 include ('../connection.php');
 header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
 header("Cache-Control: post-check=0, pre-check=0", false);
 header("Pragma: no-cache");
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <link rel="icon" type="image/png" href="assets/img/favicons.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Crudeoil Live Chart| SCube Infotec</title>
	<meta name="description" content="Get detailed information about CRUDEOIL Chart">
	<meta name="keywords" content="CRUDEOIL rates/price Live, CRUDEOIL rate/price in india Live, CRUDEOIL price, CRUDEOIL rate today Live, CRUDEOIL rates india, todays CRUDEOIL rate in india, CRUDEOIL chart, CRUDEOIL price per gram, CRUDEOIL funds, bullion stocks, CRUDEOIL Price India, Live CRUDEOIL rate India, CRUDEOIL Price Forecast">
	<meta http-equiv="pragma" content="no-cache">
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
	<?php include("headercss.php"); ?>
	<style>
		@media only screen and (max-width: 768px) {
		.contentsm{
			padding-left: 0px;
			padding-right: 0px;
			padding-top: 50px;
		}
		} 
#share-buttons img {
width: 35px;
padding: 5px;
border: 0;
box-shadow: 0;
display: inline;
}
.blink {
    animation-duration: 1s;
    animation-name: blink;
    animation-iteration-count: infinite;
    animation-timing-function: steps(2, start);
}
@keyframes blink{
    80% {
        visibility: hidden;
    }
}
	</style>
</head>
<body>
    <div class="wrapper">
		<?php include("mainmenu.php"); ?>
			<div class="main-panel">
		<?php include("headersm.php"); ?>
					<div class="content" style="padding-top: 15px;margin-top:0px;">
						<div class="container-fluid">
							<div class="row">
								<div class="col-lg-10 col-md-12 col-sm-12 contentsm">
									<div class="card">
										<div class="card-header" data-background-color="purple">
										<h4 class="title blink">Crudeoil Live Intraday Chart</h4>
										</div>
										<div class="card-content">
											<div class="row">
												<div class="col-md-12">
													<div id="div">
														<table class="table">
															<tbody>
																<tr>
																	<td colspan="4">
																	<img id="imageid_crudeintra" src="img/comm_charts/CrudeOilIntra.png" alt="CRUDEOIL">	
																	</td>
																</tr>
																<tr>
																<td colspan="4">
																		 
																</td>
																</tr>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-lg-2 col-md-12 col-sm-12 contentsm">
									 
									<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- ad3 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:200px;height:600px"
     data-ad-client="ca-pub-7550523212472920"
     data-ad-slot="5417275659"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
										<!--<div class="card-header" data-background-color="purple">
											<h4 class="title"><p  class="blink_text"> </p></h4>
										</div>
										<div class="card-content" id="imageid_screengif">
											<div class="row">
												<div class="col-md-12">
												</div>
											</div>
										</div>-->
									 
								</div>
							</div>
						</div>
						<div class="container-fluid">
							<div class="row">
								<div class="col-lg-10 col-md-12 col-sm-12 contentsm">
									<div class="card">
										<div class="card-header" data-background-color="purple">
											<h4 class="title blink">Crudeoil Live Short-term Positional Chart</h4>
										</div>
										<div class="card-content">
											<div class="row">
												<div class="col-md-12">
													<div id="div">
														<table class="table">
															<tbody>
																<tr id="screen">
																	<td colspan="4">
																	 <img id="imageid_crude" src="img/comm_charts/CrudeOil.png" alt="CRUDEOIL">									 
																	</td>
																</tr>
																<tr>
																<td colspan="4">
																</td>
																</tr>
															</tbody>	
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
									<div class="col-lg-2 col-md-12 col-sm-12 contentsm">
								<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- ad3 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:200px;height:600px"
     data-ad-client="ca-pub-7550523212472920"
     data-ad-slot="5417275659"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
								</div>
							</div>
						</div>
					<?php include("footeraboutchart.php") ?>
					</div>
				<?php include("footer.php"); ?>
			</div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/material.min.js" type="text/javascript"></script>
<!--  Charts Plugin ---------->
<!--  PerfectScrollbar Library -->
<script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
<!-- Material Dashboard javascript methods -->
<script src="assets/js/material-dashboard.js?v=1.2.0"></script>
<script type="text/javascript">
  var d = new Date().getTime();
function refresh_div() {
    var d = new Date().getTime();
            $("#imageid_crude").attr("src", "img/comm_charts/CrudeOil.png?"+d);
            $("#imageid_crudeintra").attr("src", "img/comm_charts/CrudeOilIntra.png?"+d);
}
t = setInterval(refresh_div,5000);  
</script>
</html>