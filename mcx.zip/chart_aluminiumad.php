<?php
//include ('../session.php');
//include ('../connection.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="assets/img/favicons.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Aluminium Live Chart| SCube Infotec</title>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport"/>
    <meta name="viewport" content="width=device-width" />
	<?php include("headercss.php"); ?>
	<style>
		@media only screen and (max-width: 768px) {
		.contentsm{
			padding-left: 0px;
			padding-right: 0px;
			padding-top: 50px;
		}
		}
.blink_text
{
 font-size:20px;
 font-weight:bold;
 animation: blink 1s infinite;	
}
@keyframes blink 
{  
 0% { opacity: 1.0; }
 50% { opacity: 0.0; }
 100% { opacity: 1.0; }
}
	</style>
</head>
<body>
    <div class="wrapper">
		<?php include("mainmenu.php"); ?>
			<div class="main-panel">
		<?php include("headersm.php"); ?>
					<div class="content" style="padding-top: 15px;margin-top:0px;">
						<div class="container-fluid">
							<div class="row">
								<div class="col-lg-10 col-md-12 col-sm-12 contentsm">
									<div class="card">
										<div class="card-header" data-background-color="purple">
											<h4 class="title">Aluminium Live Chart</h4>
										</div>
										<div class="card-content">
											<div class="row">
												<div class="col-md-12">
													<div id="div">
														<table class="table">
															<tbody>
																<tr>
																	<td colspan="4" id="streamTitle">
																		
																	</td>
																</tr>
																<tr>
																<td colspan="4">
																		 
																</td>
																</tr>
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-lg-2 col-md-12 col-sm-12 contentsm">
									<div class="card">
										<div class="card-header" data-background-color="purple">
											<h4 class="title"><p  class="blink_text">Open An Account</p></h4>
										</div>
										<div class="card-content" id="imageid_screengif">
											<div class="row">
												<div class="col-md-12">
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php include("footer.php"); ?>
			</div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/material.min.js" type="text/javascript"></script>
<!--  Charts Plugin -->
<!--  PerfectScrollbar Library -->
<script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
<!-- Material Dashboard javascript methods -->
<script src="assets/js/material-dashboard.js?v=1.2.0"></script>
<script>
$(document).ready(function(){
setInterval(function(){
$("#imageid_screengif").load('banners.php')
}, 2000);
});
</script>
</html>