<table class="table">
                                                <tbody>
                                                    <tr>
													<td colspan="4">
													
													<?php               
				$sqlquery=mysql_query("SELECT * from scubepositional where tdelete='0' and positionalchart_title='$tab'");
				$infosql=mysql_fetch_array($sqlquery);
				?>
				<img id="imageid<?= $tab;?>" src="https://drive.google.com/uc?export=view&id=<?=$infosql['positionalchart']?>" class="img-responsive" alt="<?=$infosql['positionalchart_title']?>"> 
													
													</td>
													</tr>
                                                    <tr>
													<td colspan="4">
													
													<?php               
				$sqlquery=mysql_query("SELECT * from scubepositional where tdelete='0' and positionalchart_title='$tab'");
				$infosql=mysql_fetch_array($sqlquery);
				?>
				<img id="imageid<?= $tab;?>" src="https://drive.google.com/uc?export=view&id=<?=$infosql['positionalchart']?>" class="img-responsive" alt="<?=$infosql['positionalchart_title']?>"> 
													
													</td>
													</tr>
                                                </tbody>
                                            </table>