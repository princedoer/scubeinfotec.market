

    <!DOCTYPE html>

    <html lang="en">

    <head>

        <meta charset="UTF-8">

        <title>File Upload Form</title>

    </head>

    <body>

        <form action="testfileupload.php" method="post" enctype="multipart/form-data">

            <h2>Upload File</h2>

            <label for="fileSelect">Filename:</label>

            <input type="file" name="photo" id="fileSelect">

            <input type="submit" name="submit" value="Upload">

            <p><strong>Note:</strong> Only .jpg, .jpeg, .gif, .png formats allowed to a max size of 5 MB.</p>

        </form>

    </body>

    </html>
 
  
<?php
$directory = "file/";

  $File_name = $_FILES["photo"]["name"];
  $Type  = $_FILES["photo"]["type"] ;
  $Size   = ($_FILES["photo"]["size"] / 1024); 
  $File_temp_name  = $_FILES["photo"]["tmp_name"];
  if($Size<= 0){
	  
	  die('cant not upload a file ');
	  }
if (file_exists($directory . " / " .  $_FILES["photo"]["name"]))
      {
      die($_FILES["photo"]["name"] . " already exists. ");
      }

  if(is_uploaded_file($_FILES["photo"]["tmp_name"])){
	  
	  if(!move_uploaded_file($File_temp_name,$directory."/".$File_name)){
		      die('cant not file'.$File_name);
		  }
	  }
	  else
	  {
	    die('attack on file');
		  }	  
		  echo $File_name . "  is sucessfully uploaded " . " <br/> " ;
		  echo "file size : " .$Size. " <br/> ";
		  echo"type :".$Type." <br/> ";
  
 ?>
 

 
