<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Page Not Found | Scube Infotec</title>
</head>
<body style="text-align:center" bgcolor="#1BBC9B"><br>
<span style="z-index:-1000px; font-size:50px; text-shadow:-2px -2px 0 #fff, 2px -2px 0 #fff, -2px 2px 0 #fff, 2px 2px 0 #fff;"><span class="text-fuchsia">Sorry! This Page is Not Found</span></span><br>
<img src="resdesimain/images/worry.jpg"><br><br>
<br>
<a href="charts.earncommodities.com" style="background-color:#AA2022; padding:10px; border-radius:5px; text-decoration:none; color:#fff;">BACK TO HOME</a>
</body>
</html>