        <div class="sidebar" data-color="purple" data-image="assets/img/sidebar-3.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

        Tip 2: you can also add an image using data-image tag
    -->
            <div class="logo">
                <a href="http://www.scubeinfotec.co.in" class="simple-text">
                    Scube Infotec
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
  <?php
$page=basename($_SERVER['PHP_SELF']);
?>
                    <li class="<?=($page=='index.php')?'active':''?>">
                        <a href="index.php">
                            <i class="material-icons">home</i>
                            <p>Home</p>
                        </a>
                    </li>
                    <li>
						<a data-toggle="collapse" href="#pagesExamples" aria-expanded="FALSE">
                            <i class="material-icons">trending_up</i>
                            <p>Live Chart<b class="caret"></b></p>
                        </a>
						<div class="collapse <?=(($page=='chart_crude.php')||($page=='chart_gold.php')||($page=='chart_silver.php')||($page=='chart_naturalgas.php')||($page=='chart_copper.php')||($page=='chart_nickel.php')||($page=='chart_aluminium.php')||($page=='chart_lead.php')||($page=='chart_zinc.php'))?'in':''?>" id="pagesExamples">
                            <ul class="nav">
                                <li class="<?=($page=='chart_crude.php')?'active':''?>">
									<a href="chart_crude.php">
										<i class="material-icons">insert_chart</i>
										<p>Crudeoil</p>
									</a>
								</li>
								<li class="<?=($page=='chart_gold.php')?'active':''?>">
									<a href="chart_gold.php">
										<i class="material-icons">insert_chart</i>
										<p>Gold</p>
									</a>
								</li>
								<li class="<?=($page=='chart_silver.php')?'active':''?>">
									<a href="chart_silver.php">
										<i class="material-icons">insert_chart</i>
										<p>Silver</p>
									</a>
								</li>
								<li class="<?=($page=='chart_naturalgas.php')?'active':''?>">
									<a href="chart_naturalgas.php">
										<i class="material-icons">insert_chart</i>
										<p>Naturalgas</p>
									</a>
								</li>
								<li class="<?=($page=='chart_copper.php')?'active':''?>">
									<a href="chart_copper.php">
										<i class="material-icons">insert_chart</i>
										<p>Copper</p>
									</a>
								</li>
								<li class="<?=($page=='chart_nickel.php')?'active':''?>">
									<a href="chart_nickel.php">
										<i class="material-icons">insert_chart</i>
										<p>Nickel</p>
									</a>
								</li>
								<li class="<?=($page=='chart_aluminium.php')?'active':''?>">
									<a href="chart_aluminium.php">
										<i class="material-icons">insert_chart</i>
										<p>Aluminium</p>
									</a>
								</li>
								<li class="<?=($page=='chart_lead.php')?'active':''?>">
									<a href="chart_lead.php">
										<i class="material-icons">insert_chart</i>
										<p>Lead</p>
									</a>
								</li>
								<li class="<?=($page=='chart_zinc.php')?'active':''?>">
									<a href="chart_zinc.php">
										<i class="material-icons">insert_chart</i>
										<p>Zinc</p>
									</a>
								</li>
                            </ul>
                        </div>
							
                    </li>
                    <li class="<?=($page=='scubelevel.php')?'active':''?>">
                        <a href="scubelevel.php">
                            <i class="material-icons">content_paste</i>
                            <p>Pivot Levels</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>