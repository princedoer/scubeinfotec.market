            <footer class="footer">
                <div class="container-fluid">
                    <nav class="pull-left">
                        <ul>
                            <li>
								<a href="#" data-toggle="modal" data-target="#myDisclaim">Disclaimer
								</a>
								<!-- Disclaimer Modal Core -->
								<div class="modal fade" id="myDisclaim" tabindex="-1" role="dialog" aria-labelledby="myDisclaimLabel" aria-hidden="true">
								  <div class="modal-dialog">
									<div class="modal-content">
									  <div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
										<h4 class="modal-title" id="myDisclaimLabel">Disclaimer</h4>
									  </div>
									  <div class="modal-body">
										<p>You agree and understand that the information and material contained in this website implies and constitutes your consent to the terms and conditions mentioned. You also agree that SCube Infotec can modify or alter the terms and conditions of the use of this service without any liability. </p>

										<p>The content of the site and the interpretation of data are solely the personal views of the contributors. SCube Infotec reserves the right to make modifications and alterations to the content of the website. Users are advised to use the data for the purpose of information only and rely on their own judgment while making investment/trading decisions. The investments/trading ideas discussed or recommended may not be suitable for all investors/traders. SCube Infotec does not warranty the timeliness, accuracy or quality of the electronic content. </p>

										<p>The content of the website cannot be copied, reproduced, republished, uploaded, posted, transmitted or distributed for any non-personal use without obtaining prior permission from SCube Infotec, We reserve the right to terminate the accounts of subscribers/customers, who violate the proprietary rights, in addition to necessary legal action. </p>

										<p>SCube Infotec and its owners/affiliates are not liable for damages caused by any performance, failure of performance, error, omission, interruption, deletion, defect, delay in transmission or operations, computer virus, communications line failure, and unauthorized access to the personal accounts. SCube Infotec is not responsible for any technical failure or malfunctioning of the software or delays of any kind. We are also not responsible for non-receipt of registration details or e-mails. Users shall bear all responsibility of keeping the password secure. SCube Infotec is not responsible for the loss or misuse of the password.</p>

										<p>SCube Infotec is not responsible for the content of any of the linked sites. By providing access to other web- sites, SCube Infotec is neither recommending nor endorsing the content available in the linked websites.</p>
									  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-default btn-simple" data-dismiss="modal">Close</button>
									  </div>
									</div>
								  </div>
								</div>
                            </li>
                            <li>
                                <a href="#">
                                    Privacy Policy
                                </a>
                            </li>
                            <li>
                                <a href="http://scubeinfotec.co.in/#about">
                                    About Us
                                </a>
                            </li>
                            <li>
                                <a href="http://scubeinfotec.co.in/#contact pb-5">
                                    Contactus
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <p class="copyright pull-right">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                        <a href="http://scubeinfotec.co.in"> SCube Infotec</a>, designed for traders, for a better trading experience
                    </p>
                </div>
            </footer>