<div class="container-fluid">
							<div class="row">
								<div class="col-lg-10 col-md-12 col-sm-12 contentsm">
									<div class="card">
										<div class="card-header" data-background-color="purple">
											<h4 class="title">About our Chart</h4>
											
										</div>
										<div class="card-content">
											<div class="row">
												<div class="col-md-12">
													<div id="div">
														<table class="table">
															<tbody>
																<tr id="screen">
																	<td colspan="4">
<b><span style="font-family: &quot;verdana&quot; , sans-serif;">Horizontal dotted line</span></b><br>
<ul>
<li>WHITE - 6 month's HIGH or LOW</li>
<li>BLUE  - Important support-resistance (alert) zones</li>
</ul>
<b><span style="font-family: &quot;verdana&quot; , sans-serif;">Horizontal Continuous line</span></b><br>
<ul>
<li>PURPLE - YH-Yesterday HIGH</li>
<li>PURPLE - YL-Yesterday LOW</li>
</ul>
<b><span style="font-family: &quot;verdana&quot; , sans-serif;">Trend-Line dotted line</span></b><br>
<ul>
<li>GREEN - TrendLines (UpTrend)</li>
<li>RED   - TrendLines (DownTrend)</li>
</ul>
<b><span style="font-family: &quot;verdana&quot; , sans-serif;">When to enter trade</span></b><br>
<ul>
<li>Go Long (BUY), when the chart shows GREEN UP ARROW</li>
<li>Go Short (SELL), when the chart shows RED DOWN ARROW</li>
</ul>
<div>
</div>
<b><span style="font-family: &quot;verdana&quot; , sans-serif;">When to exit trade</span></b><br>
<ul>
<li>Place Target's and Stoploss as mentioned</li>
</ul>
<div>
<br></div>
<b><span style="font-family: &quot;verdana&quot; , sans-serif;">Note: </span></b><br>
<ul>
<li>The charts shown above is for study purpose only. </li>
<li>We can't guarantee you the accuracy level of the data shown here.</li>
<li>Read disclaimer before entering into Real trade. </li>
</ul>

																		 
																	</td>
	
	
																</tr>
																<tr>
																<td colspan="4">
							
																
																</td>
																</tr>
															</tbody>	
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>