<?php $page=basename($_SERVER['PHP_SELF']); ?>			
			<nav class="navbar navbar-transparent navbar-absolute">
                <div class="container-fluid">
                    <div class="navbar-header"> 
                        <button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
						<?php if($page=="index.php"){ ?>
							<a class="navbar-brand" href="index.php">Commodity Market </a>
						<?php }if($page=="chart_crude.php"){ ?>
							<a class="navbar-brand" href="chart_crude.php">Crudeoil Live Chart </a>
						<?php }if($page=="chart_gold.php"){ ?>
							<a class="navbar-brand" href="chart_gold.php">Gold Live Chart </a>
						<?php }if($page=="chart_silver.php"){ ?>
							<a class="navbar-brand" href="chart_silver.php">Silver Live Chart </a>
						<?php }if($page=="chart_naturalgas.php"){ ?>
							<a class="navbar-brand" href="chart_naturalgas.php">Natural Gas Live Chart </a>
						<?php }if($page=="chart_copper.php"){ ?>
							<a class="navbar-brand" href="chart_copper.php">Copper Live Chart </a>
						<?php }if($page=="chart_nickel.php"){ ?>
							<a class="navbar-brand" href="chart_nickel.php">Nickel Live Chart </a>
						<?php }if($page=="chart_aluminium.php"){ ?>
							<a class="navbar-brand" href="chart_aluminium.php">Aluminium Live Chart </a>
						<?php }if($page=="chart_lead.php"){ ?>
							<a class="navbar-brand" href="chart_lead.php">Lead Live Chart </a>
						<?php }if($page=="chart_zinc.php"){ ?>
							<a class="navbar-brand" href="chart_zinc.php">Zinc Live Chart </a>
						<?php } ?>
                    </div>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                           
                            <li>
                                <a href="//www.facebook.com/SCubeinfotec/">
                                    <i class="fa fa-facebook-official" aria-hidden="true"></i>
                                </a>
                            </li>
                            <li>
                                <a href="//www.twitter.com/scubeinfotec/">
                                    <i class="fa fa-twitter-square" aria-hidden="true"></i>
                                </a>
                            </li>
                            <li>
                                <a href="//plus.google.com/u/3/102584813737934993467?prsrc=3">
                                    <i class="fa fa-google-plus-square" aria-hidden="true"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
				
            </nav>