<?php
//include ('../session.php');
//include ('../connection.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="assets/img/favicons.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Crudeoil Live Chart | SCube Infotec</title>
	<meta name="description" content="Get detailed information about CRUDEOIL Chart">
	<meta name="keywords" content="CRUDEOIL rates/price Live, CRUDEOIL rate/price in india Live, CRUDEOIL price, CRUDEOIL rate today Live, CRUDEOIL rates india, todays CRUDEOIL rate in india, CRUDEOIL chart, CRUDEOIL price per gram, CRUDEOIL funds, bullion stocks, CRUDEOIL Price India, Live CRUDEOIL rate India, CRUDEOIL Price Forecast">
	<meta http-equiv="pragma" content="no-cache">
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
<meta name="twitter:card" content="CurdeOil Live Chart">
<meta name="twitter:site" content="@Scubeinfotec">
<meta name="twitter:creator" content="@Scubeinfotec">
<meta name="twitter:title" content="CurdeOil Live Chart">
<meta name="twitter:description" content="CurdeOil Live Chart">
<meta name="twitter:image" content="img/comm_charts/CrudeOil.png">
<meta property="og:title" content="CurdeOil Live Chart" />
<meta property="og:description" content="CurdeOil Live Chart" />
 <meta property="og:url" content="http://scubeinfotec.co.in" />
<meta property="og:image" content="http://mcx.scubeinfotec.co.in/img/comm_charts/CrudeOiltw.png" /> 
	<?php include("headercss.php"); ?>
	<style>
		@media only screen and (max-width: 768px) {
		.contentsm{
			padding-left: 0px;
			padding-right: 0px;
			padding-top: 50px;
		}
		} 
#share-buttons img {
width: 35px;
padding: 5px;
border: 0;
box-shadow: 0;
display: inline;
}
img{
	-moz-user-select: none;
	pointer-events: none;
}
.blink {
    animation-duration: 1s;
    animation-name: blink;
    animation-iteration-count: infinite;
    animation-timing-function: steps(2, start);
}
@keyframes blink{
    80% {
        visibility: hidden;
    }
}
/* Hide AddToAny vertical share bar when screen is less than 980 pixels wide */
@media screen and (max-width: 980px) {
    .a2a_floating_style.a2a_vertical_style { display: none; }
}
	</style>
	<script type='text/javascript'>
    var __ac = {};
    __ac.uid = "afaaf198468876d9299f9f00df4dfe14";
    __ac.server = "secure.chatrify.com";

    (function() {
      var ac = document.createElement('script'); 
      ac.type = 'text/javascript'; 
      ac.async = true;
      ac.src = 'https://cdn.chatrify.com/go.js';
      var s = document.getElementsByTagName('script')[0]; 
      s.parentNode.insertBefore(ac, s);
    })();
</script>

</head>
<body >
    <div class="wrapper">
		<?php include("mainmenu.php"); ?>
			<div class="main-panel">
		<?php include("headersm.php"); ?>
					<div class="content" style="padding-top: 15px;margin-top:0px;">
						<div class="container-fluid">
							<div class="row">
								<div class="col-lg-10 col-md-12 col-sm-12 contentsm">
									<div class="card">
										<div class="card-header" data-background-color="purple">
											<h4 class="title blink">Crudeoil Live Intraday Chart</h4>
											
										</div>
										<div class="card-content">
											<div class="row">
												<div class="col-md-12">
													<div id="div">
														<table class="table">
															<tbody>
																<tr id="screen">
																	<td colspan="4">
																	 <img id="imageid_crudeintra" src="img/comm_charts/CrudeOilIntra.png"   alt="CRUDEOIL" draggable="false">  
																		 
																	</td>
	
	
																</tr>
																<tr>
																<td colspan="4">
							<!-- AddToAny BEGIN
<div class="a2a_kit a2a_kit_size_32 a2a_floating_style a2a_default_style" data-a2a-url="http://mcx.scubeinfotec.co.in/chart_cruderef.php" style="bottom:0px; left:80%; margin-left:-100px;">
<a class="a2a_dd" href="https://www.addtoany.com/share"></a>
<a class="a2a_button_facebook"></a>
<a class="a2a_button_twitter"></a>
<a class="a2a_button_google_plus"></a>
<a class="a2a_button_whatsapp"></a>
<a class="a2a_button_telegram"></a>
</div>
<script async src="https://static.addtoany.com/menu/page.js"></script> -->
<!-- AddToAny END -->

																
																</td>
																</tr>
															</tbody>	
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="container-fluid">
							<div class="row">
								<div class="col-lg-10 col-md-12 col-sm-12 contentsm">
									<div class="card">
										<div class="card-header" data-background-color="purple">
											<h4 class="title blink">Crudeoil Live Short-term Positional Chart</h4>
											
										</div>
										<div class="card-content">
											<div class="row">
												<div class="col-md-12">
													<div id="div">
														<table class="table">
															<tbody>
																<tr id="screen">
																	<td colspan="4">
																	 <img id="imageid_crude" src="img/comm_charts/CrudeOil.png"   alt="CRUDEOIL" draggable="false">  
																		 
																	</td>
	
	
																</tr>
																<tr>
																<td colspan="4">
							
																
																</td>
																</tr>
															</tbody>	
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					<?php include("footeraboutchart.php") ?>
					</div>
				<?php include("footer.php"); ?>
			</div>
    </div>
	<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5a02a40ccebb3bb9"></script>

</body>
<!--   Core JS Files   -->
<script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/material.min.js" type="text/javascript"></script>
<!--  Charts Plugin -->
<!--  PerfectScrollbar Library -->
<script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
<!-- Material Dashboard javascript methods -->
<script src="assets/js/material-dashboard.js?v=1.2.0"></script>
<script type="text/javascript">

  var d = new Date().getTime();
function refresh_div() {
    var d = new Date().getTime();
    jQuery.ajax({
        url:'chart_cruderef.php?ts=' + d,
        type:'POST',
        success:function(results) {
            $("#imageid_crude").attr("src", "img/comm_charts/CrudeOil.png?"+d);
            $("#imageid_crudeintra").attr("src", "img/comm_charts/CrudeOilIntra.png?"+d);
        }
    });
}
t = setInterval(refresh_div,5000);  
    window.oncontextmenu = function () {
            return false;
        }
        $(document).keydown(function (event) {
            if (event.keyCode == 123) {
                return false;
            }
            else if ((event.ctrlKey && event.shiftKey && event.keyCode == 73) || (event.ctrlKey && event.shiftKey && event.keyCode == 74)) {
                return false;
            }
        });  
		    $(document).keydown(function(event) { 
        var pressedKey = String.fromCharCode(event.keyCode).toLowerCase();
        
        if (event.ctrlKey && (pressedKey == "c" || pressedKey == "u")) {
            alert('Sorry, This Functionality Has Been Disabled!'); 
            //disable key press porcessing
            return false; 
        }
    });
		 
/* var x=0, y=0;
var canvas, context, img;
function timedRefresh()
{
    canvas = document.getElementById("y");
    context = canvas.getContext("2d");
    img = new Image();
    img.src = "http://mcx.scubeinfotec.co.in/img/comm_charts/CrudeOil.gif?t=" + new Date().getTime();
    img.onload = function() {
		context.drawImage(img, x, y);
		x+=0; y+=0;
		setTimeout("timedRefresh()",5000); 
	};
	
}
window.onload =timedRefresh; */


</script>
</html>