<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="assets/img/favicons.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>MCX | Home Page  | SCube Infotec</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
	<?php include("headercss.php"); ?>
	<style>
	
.card [data-background-color="inkblue"] {
    background:linear-gradient(60deg, #0077b5, rgba(31, 153, 216, 0.74));
    box-shadow: 0 12px 20px -10px  rgba(0, 119, 181,0.28), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgba(0, 188, 212, 0.2);
}
.card [data-background-color="fbblue"] {
    background:linear-gradient(60deg, #ef5350, #0077b5));
    box-shadow: 0 12px 20px -10px  rgba(0, 119, 181,0.28), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgba(0, 188, 212, 0.2);
}
.blink_text
{
 font-size:20px;
 font-weight:bold;
 animation: blink 1s infinite;	
}
@keyframes blink 
{  
 0% { opacity: 1.0; }
 50% { opacity: 0.0; }
 100% { opacity: 1.0; }
}
	</style>
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-7550523212472920",
    enable_page_level_ads: true
  });
</script>
</head>

<body>
    <div class="wrapper">
	<?php include("mainmenu.php");?>
        <div class="main-panel">
	<?php include("header.php");?>
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-8 col-md-12 col-sm-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <h4 class="title">Economic Calendar</h4>
                                </div>
                                <div class="card-content">
								<iframe src="https://sslecal2.forexprostools.com?columns=exc_flags,exc_currency,exc_importance,exc_actual,exc_forecast,exc_previous&features=datepicker,timezone,timeselector,filters&countries=25,34,32,6,37,72,71,22,17,51,39,14,33,10,35,42,43,45,38,56,36,110,11,26,9,12,41,4,5,178&calType=today&timeZone=23&lang=56" width="650" height="467" frameborder="0" allowtransparency="true" marginwidth="0" marginheight="0"></iframe><div class="poweredBy" style="font-family: Arial, Helvetica, sans-serif;"><span style="font-size: 11px;color: #333333;text-decoration: none;">Real Time Economic Calendar provided by <a href="https://in.Investing.com/" rel="nofollow" target="_blank" style="font-size: 11px;color: #06529D; font-weight: bold;" class="underline_link">Investing.com India</a>.</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 col-sm-12">
							<div class="card card-nav-tabs">
                                <div class="card-content">
									<div class="row">
										<div class="col-md-6">
											<div class="alert alert-danger">
												<span align="center"><a href="chart_crude.php"><p  class="blink_text">Live Chart</p></a></span>
											</div>
										</div>
										<div class="col-md-6">
											<div class="alert alert-success">
												<span align="center"align="center"><a href="scubelevel.php"><p  class="blink_text">Pivot Level</p></a></span>
											</div>
										</div>
									</div>
                                </div>
                            </div>
                        </div>
								
                        <div class="col-lg-4 col-md-12 col-sm-12">
							<div class="card card-stats">
                                <div class="card-header" data-background-color="green">
                                    <i class="fa fa-file-excel-o" aria-hidden="true"></i>
                                </div>
                                <div class="card-content">
									<a href="img/file/BhavCopy.xls">
										<i class="material-icons">file_download</i>
										<p>BhavCopy File Download </p>
									</a>
								</div>
                            </div>
                        </div>
				
                        <div class="col-lg-4 col-md-12 col-sm-12">
							<div class="card card-stats">
                                <div class="card-header" data-background-color="green">
                                    <i class="fa fa-file-excel-o" aria-hidden="true"></i>
                                </div>
                                <div class="card-content">
									<a href="img/file/MarginCopy.xls">
										<i class="material-icons">file_download</i>
										<p>Margin File Download </p>
									</a>
								</div>
                            </div>
                        </div>   
						
                        <div class="col-lg-4 col-md-12 col-sm-12">
							<div class="card card-stats">
                                <div class="card-header" data-background-color="green">
                                    <i class="fa fa-file-archive-o" aria-hidden="true"></i>
                                </div>
                                <div class="card-content">
									<a href="software.php">
										<i class="material-icons">file_download</i>
										<p>Software Download</p>
									</a>
								</div>
                            </div>
                        </div> 
 	
	
                    </div>
                    <div class="row">
						<div class="col-lg-8 col-md-12 col-sm-12">
                            <div class="card">
                                <div class="card-header" data-background-color="orange">
                                    <h4 class="title">News & Event's</h4>
                                </div>
                                <div class="card-content">
					<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FSCubeinfotec%2F&tabs=timeline&width=500&height=500&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="500" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
                                </div>
                            </div>
                        </div>
					</div>
					<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-format="fluid"
     data-ad-layout-key="-fg+5m+7r-g6+16"
     data-ad-client="ca-pub-7550523212472920"
     data-ad-slot="8018554115"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
                </div>
            </div>	
			<?php include("footer.php");?>
        </div>
    </div>
</body>
<!--   Core JS Files   -->	
<script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/material.min.js" type="text/javascript"></script>
<!--  PerfectScrollbar Library -->
<script src="assets/js/perfect-scrollbar.jquery.min.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/js/bootstrap-notify.js"></script>
<!-- Material Dashboard javascript methods -->
<script src="assets/js/material-dashboard.js?v=1.2.0"></script>
</html>