            <footer class="footer">
                <div class="container-fluid">
                    <nav class="pull-left">
                        <ul>
                            <li>
                                <a href="#">
                                    Disclaimer
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Privacy Policy
                                </a>
                            </li>
                            <li>
                                <a href="http://charts.earncommodities.com/#about">
                                    About Us
                                </a>
                            </li>
                            <li>
                                <a href="http://charts.earncommodities.com/#contact pb-5">
                                    Contactus
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <p class="copyright pull-right">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                        <a href="http://www.creative-tim.com">Scube Infotec</a>, trade with us, for a better experience
                    </p>
                </div>
            </footer>