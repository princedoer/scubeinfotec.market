<?php
/*include ('../connection.php');
	if($_GET['scrip'])
	{
echo "<img id='imageid_crudeoil' src='../img/comm_charts/CrudeOil.png' class='auto_img'>";
}*/
?>
<?php
$bg_array = array("#CEED9D","#ECED9D","#EDCF9D","#EC9CA7","#ED9DD0","#EE9DE2","#D69DEC","#9E9CEC");
$bg = array_rand($bg_array,1);
?>
<div class="banner" style="background-color:<?php echo $bg_array[$bg];?>;" >
<div class="txt-title">jQuery DIV Auto Load Refresh</div>
<div class="txt-subtitle">This Banner auto loads and refreshes every 2 seconds.</div>
</div>

<img id='imageid_crudeoil' src='../img/comm_charts/CrudeOil.png' class='auto_img'>